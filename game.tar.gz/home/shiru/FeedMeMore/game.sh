#!/usr/bin/env bash
cd /home/shiru/FeedMeMore && python3 /home/shiru/FeedMeMore/snake.py
